//
//  ViewController.swift
//  BusquedaDeISBN
//
//  Created by Juan Felipe Chávez on 28/07/16.
//  Copyright © 2016 JuanFelipeChávez. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtvwResultados: UITextView!
    @IBOutlet weak var txtClaveIsbn: UITextField!


    func sincrono(pISBN: String) throws {

        let urls =  "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:" + pISBN
        let url =  NSURL(string: urls)
        let datos:NSData? =  NSData(contentsOfURL: url!)

        if datos == nil{
             txtvwResultados.text = "No se encontraron Datos. Esto puede ser porque el ISBN no existe o no tiene conexion de Internet persistente"
        }else{

        let texto =  NSString(data:datos!, encoding:NSUTF8StringEncoding)
        txtvwResultados.text = texto! as String

        }

    }

    /* Si queremos que funcione de manera asincrona (Sin esperar respuesta del servidor

    func asincrono()   {

        let urls = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:978-84-376-0494-7"
        let url = NSURL(string: urls)
        let sesion = NSURLSession.sharedSession()
        let bloque = { (datos: NSData?, resp : NSURLResponse?, error : NSError? ) -> Void in
            let texto = NSString(data: datos!, encoding:NSUTF8StringEncoding)
            print (texto!)
        }

        let dt = sesion.dataTaskWithURL(url!, completionHandler: bloque)
        dt.resume()
        print("antes o después")
        
    }
*/


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.



    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnLimpiar(sender: AnyObject) {

        txtClaveIsbn.text = ""
        
    }

    func textFieldShouldReturn(textField: UITextField) -> Bool {
        if textField == txtClaveIsbn{
            do{
                try
                sincrono(txtClaveIsbn.text!)
                txtClaveIsbn.resignFirstResponder()
                return true
            }//End Do
            catch
            {
                txtvwResultados.text = "Se ha provocado un error"
                return false
            }//End Catch
        }//End if
        else
        {
            return false
        }

    }



}

